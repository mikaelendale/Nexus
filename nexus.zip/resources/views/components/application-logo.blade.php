<img src="{{asset('images/Nexus.png')}}" width="50" alt="img-fluid">
