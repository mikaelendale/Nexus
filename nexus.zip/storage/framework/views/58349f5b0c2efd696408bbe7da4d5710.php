<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Details')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 dark:text-gray-100">Volunteer Information</h3>
                    <div class="mt-4 grid grid-cols-1 md:grid-cols-2 gap-6" style="padding: 20px; border-radius: 10px;"
                        id="volunteer-detail">
                        <!-- Volunteer Details -->
                        <div>
                            <p><strong>Name:</strong> <?php echo e($volunteer->name); ?></p>
                            <p><strong>Volunteer ID:</strong> <?php echo e($volunteer->volunteer_id); ?></p>
                            <!-- Add more fields as necessary -->
                        </div>

                        <!-- Form and Progress Bar -->
                        <div>
                            <!-- Display Validation Errors -->
                            <?php if($errors->any()): ?>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4"
                                            role="alert">
                                            <strong class="font-bold">Error!</strong>
                                            <span class="block sm:inline"><?php echo e($error); ?></span>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>

                            <!-- Check for success message and display it -->
                            <?php if(session('success')): ?>
                                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4"
                                    role="alert">
                                    <strong class="font-bold">Success!</strong>
                                    <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                                </div>
                            <?php endif; ?>

                            <!-- Form -->
                            <form action="<?php echo e(route('updated.hours', ['volunteer' => $volunteer->id])); ?>" method="POST"
                                class="mb-4">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div>
                                    <label for="day"
                                        class="block text-sm font-medium text-gray-700 dark:text-gray-300">Day</label>
                                    <select name="day" id="day"
                                        class="mt-1 block w-full rounded-md bg-gray-100 dark:bg-gray-700 border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                                        <option value="monday">Monday</option>
                                        <option value="tuesday">Tuesday</option>
                                        <option value="wednesday">Wednesday</option>
                                        <option value="thursday">Thursday</option>
                                        <option value="friday">Friday</option>
                                        <option value="saturday">Saturday</option>
                                        <option value="sunday">Sunday</option>
                               </div>          </select>


                                <div class="mt-4">
                                    <label for="hours"
                                        class="block text-sm font-medium text-gray-700 dark:text-gray-300">Amount of
                                        Hours</label>
                                    <input type="number" name="hours" id="hours"
                                        class="mt-1 block w-full rounded-md bg-gray-100 dark:bg-gray-700 border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                                </div>

                                <div class="mt-4 flex justify-end">
                                    <button type="submit"
                                        class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Submit</button>
                                </div><br>
                            </form>

                            <!-- Progress Bar Calculation -->
                            <?php
                                $totalHours = $volunteer->total ?? 0;
                                $percentage = ($totalHours / 72) * 100;
                            ?>
                            <!-- Progress Bar -->
                            <div class="w-full bg-gray-200 rounded-full h-4 mb-4">
                                <div class="h-4 rounded-full"
                                    style="width: <?php echo e($percentage); ?>%; background-color: <?php echo e($percentage >= 100 ? 'green' : 'blue'); ?>;">
                                </div>
                            </div>
                            <div class="flex justify-between">
                                <span
                                    class="text-sm font-medium text-gray-600 dark:text-gray-300"><?php echo e(number_format($percentage, 2)); ?>%</span>
                                <span class="text-sm font-medium text-gray-600 dark:text-gray-300"><?php echo e($totalHours); ?>

                                    out of 72 hours completed</span>
                            </div>

                        </div>
                    </div>
                    <div class="mt-4 flex justify-between">
                        <a href="<?php echo e(route('dashboard')); ?>" class="py-4 px-2 text-indigo-600 hover:text-indigo-900">Go
                            Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ikzax\Documents\GitHub\Nexus\resources\views\show.blade.php ENDPATH**/ ?>